module DbConnection where

import Database.MySQL.Base
import qualified Data.ByteString.Char8 as BS

-- Function to establish a connection to MySQL
connectToMySQL :: IO MySQLConn
connectToMySQL = do
    conn <- connect $
      ConnectInfo {
        ciHost = "localhost",
        ciUser = BS.pack "helloWorld",
        ciPassword = BS.pack "scape",
        ciDatabase = BS.pack "jdb",
        ciPort = 3306,
        ciCharset = 33
      }
    putStrLn "Connected to MySQL database!"
    return conn
