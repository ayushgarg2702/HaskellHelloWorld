module Main where
import DbConnection
import RunSqlQuery
import Database.MySQL.Base
import Rest.RestApi
import Monad.CustomMonad

main :: IO ()
main = do
  conn <- connectToMySQL
  callCustomMonad
  runQuery conn
  close conn
  putStrLn "Hello, World!"
  routes conn

  -- putStrLn "Work done"
